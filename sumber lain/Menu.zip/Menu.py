#IMPORT
import tkinter as tk
from tkinter import ttk
from tkinter import *

# DATABASE
from Workstation import Workstation
from Product import Product
from Material import Material
from Display import displaytime

#WINDOW STANDARD
window=tk.Tk()
window.title('Assembly Line Simulation 0.1')
window.geometry('700x500')
window.resizable(0, 0)

#WINDOW CONFIG

kumpulan_entry=[]
input_data=["Name of Production Line", "Process at Assembly 1", "Process at Assembly 2", "Process at Assembly 3"]

def buat_window():
    window_New=tk.Toplevel(window)
    window_New.title("New Configuration")

    for isi_input_data in input_data:
        a = StringVar()
        frame_New1=tk.Frame(master=window_New)
        label_New1=tk.Label(frame_New1,text=isi_input_data,width=30,anchor="w")
        entry_New1=tk.Entry(frame_New1,width=50, textvariable=a)
        frame_New1.pack(side=TOP,expand=YES,fill=BOTH)
        label_New1.pack(side=LEFT,expand=YES,fill=BOTH)
        entry_New1.pack(side=RIGHT,expand=YES,fill=BOTH)
        kumpulan_entry.append(entry_New1)
    frame_New2=tk.Frame(window_New)
    button_New=tk.Button(frame_New2,text="Done",anchor="center",
                         command=lambda:[command_menu_pabrik_baru(),window_New.destroy()]).pack(side=BOTTOM)
    frame_New2.pack(side=BOTTOM,expand=YES,fill=BOTH)


#GAMBAR
img_px = tk.PhotoImage(file="img_px.png")


#MENU BAR
menubar=Menu(window)
filemenu=Menu(menubar,tearoff=0)
filemenu.add_command(label="New Configuration", command=buat_window)
filemenu.add_separator()
filemenu.add_command(label="Exit", command=window.quit)
menubar.add_cascade(label="Menu", menu=filemenu)

window.config(menu=menubar)

workstation_name_list=[]
workstation_buffer_list=[]
workstation_list = []

#MENU CONFIG FULL
def command_menu_pabrik_baru():

    for isi_kumpulan_entry in kumpulan_entry:
        window.title(kumpulan_entry[0].get())

    workstation_name_satu = str(kumpulan_entry[1].get())
    workstation_name_dua = str(kumpulan_entry[2].get())
    workstation_name_tiga = str(kumpulan_entry[3].get())
    workstation_name_list = [workstation_name_satu, workstation_name_dua, workstation_name_tiga]

    #WORKSTATION LIST
    global workstation_list
    temp = Workstation("endinventory", None)
    workstation_list.append(temp)
    for i in range(len(workstation_name_list) - 1, -1, -1):
        temp = Workstation(workstation_name_list[i], temp)
        workstation_list.insert(0, temp)


    # MAKING WORKSTAION'S INVENTORY
    global workstation_buffer_life
    for i in range(len(workstation_name_list)):
        buffername = f"Buffer-{workstation_name_list[i]}"
        temp = Workstation(buffername, workstation_list[i])
        workstation_buffer_list.append(temp)

#INTERFACE
# TEXTBOX
information_box = tk.Text(window,height="10",width="30")
information_box.grid(column=9, row=9, rowspan=3)


# LABEL

ttk.Label(text = 'Operator List', font =('times new roman', 11)).grid(column=2,row=5)
ttk.Label(text = 'Inventory List', font =('times new roman', 11)).grid(column=2,row=12,pady=10,ipady=10)
ttk.Label(text = 'Information', font =('times new roman', 11)).grid(column=9,row=8,pady=20)
ttk.Label(text = 'Process Simulation', font =('times new roman', 11)).grid(column=2,row=9)
ttk.Label(text = 'Cargo Ready', font =('times new roman', 11)).grid(column=5,row=9)


# INFO WORK STATION
def inventory1_info():
    information_box.delete("1.0", tk.END)
    information_box.insert(tk.INSERT, workstation_buffer_list[0].id)

def  inventory2_info():
    information_box.delete("1.0", tk.END)
    information_box.insert(tk.INSERT, workstation_buffer_list[1].id)
    return

def  inventory3_info():
    information_box.delete("1.0", tk.END)
    information_box.insert(tk.INSERT, workstation_buffer_list[2].id)
    return

# INFO OPERATOR
def operator1_info():
    information_box.delete("1.0",tk.END)
    information_box.insert(tk.INSERT, info_operator1)
    return

def operator2_info():
    information_box.delete("1.0",tk.END)
    information_box.insert(tk.INSERT, info_operator2)
    return

def operator3_info():
    information_box.delete("1.0",tk.END)
    information_box.insert(tk.INSERT, info_operator3)
    return

# INFO PRODUCT
def product1_info():
    information_box.delete("1.0",tk.END)
    information_box.insert(tk.INSERT,info_product1)
    return

def product2_info():
    information_box.delete("1.0",tk.END)
    information_box.insert(tk.INSERT,info_product2)
    return

def product3_info():
    information_box.delete("1.0",tk.END)
    information_box.insert(tk.INSERT,info_product3)
    return


# DICTIONARY
product_color ={
    -1: "gray",
    0: "gray",
    1: "blue",
    2: "red",
    3: "yellow",
    4: "blue",
    5: "red",
    6: "yellow",

}

#COUNTER
counter = 0
global time
time = 0


# BUTTON START
def start_pencet():
    global counter
    counter += 1
    if counter <= 6:
        product1.configure(bg=product_color[0+counter])
        product2.configure(bg=product_color[-1+counter])
        product3.configure(bg=product_color[-2+counter])
    elif counter > 6:
        counter = 2
    return(counter)


clicks = 0

def addClick():
  global clicks #this will use the variable to count
  clicks = clicks + 1
  if clicks < 0:
      lbl.configure(text=0)
  if clicks > 3:
      lbl.configure(text=clicks - 3 )

def reset_button():
    product1.configure(bg='gray')
    product2.configure(bg='gray')
    product3.configure(bg='gray')
    product3.configure(bg='gray')
    system_reset = 'The system has been reset'
    global counter
    counter = 0
    global clicks
    clicks = 0
    lbl.configure(text=clicks)
    return ()

# GAMBAR
img_px = tk.PhotoImage(file="img_px.png")
operator = tk.PhotoImage(file="operator1.png")
tools = tk.PhotoImage(file="inventory.png")
picproduct =  tk.PhotoImage(file="product.png")

# CONVEYOR
conveyor = tk.Button(window, image = img_px)
conveyor.grid(column=1, row=10, columnspan=3,sticky='we',padx=0)
conveyor.config(height=10, width=100, bg="green", state = "disable")

# START BUTTON
start_click = tk.Button(window,image=img_px, text="START CYCLE", compound = "center",
                     command=lambda:[start_pencet(), addClick()])
start_click.grid(column=9, row=12,columnspan=2,sticky='w')

# RESET BUTTON
reset_button = tk.Button(window,image=img_px, text="RESET", compound = "center",
                     command=reset_button)
reset_button.grid(column=9, row=12,columnspan=2,sticky='e')


# INVENTORY
inventory1 = tk.Button(image =tools, compound = 'center', command = lambda : inventory1_info())
inventory1.grid(column=1, row=19)
inventory1.config(height=42, width=42)

inventory2 = tk.Button(image =tools , compound = 'center', command = lambda : inventory2_info())
inventory2.grid(column=2, row=19)
inventory2.config(height=42, width=42)

inventory3=tk.Button(image =tools, compound = 'center', command = lambda : inventory3_info())
inventory3.grid(column=3, row=19,sticky='w')
inventory3.config(height=42, width=42)

# OPERATOR
operator1=tk.Button(image = operator, compound = 'center', command = lambda : operator1_info())
operator1.grid(column=1, row=6)
operator1.config(height=42, width=42)

operator2 = tk.Button(image = operator, compound = 'center', command = lambda : operator2_info())
operator2.grid(column=2, row=6)
operator2.config(height=42, width=42)

operator3=tk.Button(image = operator, compound = 'center', command = lambda : operator3_info())
operator3.grid(column=3, row=6,sticky='w',padx=0)
operator3.config(height=42, width=42)


# PRODUCT
frame_product1 = tk.Frame(window, height="20", width="20")
product1 = tk.Button(frame_product1, image = img_px, command = lambda : product1_info())
frame_product1.grid(column=1, row=10,pady=20)
product1.grid(column=1, row=2)
product1.config(height=20, width=20, bg="gray")


frame_product2 = tk.Frame(window, height="50", width="50")
product2 = tk.Button(frame_product2, image = img_px, command = lambda : product2_info())
frame_product2.grid(column=2, row=10)
product2.grid(column=1, row=2)
product2.config(height=20, width=20, bg="gray")

frame_product3 = tk.Frame(window, height="50", width="50")
product3 = tk.Button(frame_product3, image = img_px, command = lambda : product3_info())
frame_product3.grid(column=3, row=10,sticky='w',padx=10)
product3.grid(column=2, row=2)
product3.config(height=20, width=20, bg="gray")

#CARGO READY
lbl= tk.Label(image = img_px, compound = 'center', text = clicks)
lbl.grid(column=5, row=10)
lbl.config(height=42, width=42)

#SPACER
frame_kosong=tk.Frame(window, width="50")
frame_kosong.grid(column=4, row=0)
frame_kosong=tk.Frame(window, width="50")
frame_kosong.grid(column=8, row=0)

# DATABASE
info_ws1 = """Config your process in the menu
"""

info_ws2 = """Config your process in the menu
"""

info_ws3 = """Config your process in the menu
"""

# INFO OPERATOR
info_operator1 = """Operator 1
ID A111
Grade A     
"""

info_operator2 = """Operator 2
ID A222
Grade A    
"""

info_operator3 = """Operator 3
ID A333
Grade A   
"""

# INFO PRODUCT
if product1.configure(bg="grey"):
    info_product1 = """There is no process yet"""
else:
    info_product1 = """Engine is being installed"""
if product2.configure(bg="gray"):
    info_product2 = """There is no process yet"""
else:
    info_product2 = """Cabin is being installed"""
if product3.configure(bg="gray"):
    info_product3 = """There is no process yet"""
else:
    info_product3 = """Door is being installed"""

#-----------------------------------------------------------------------------------------------------------------------
window.mainloop()

